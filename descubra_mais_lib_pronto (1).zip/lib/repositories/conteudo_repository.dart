import 'package:flutter/material.dart';
import '../models/conteudo.dart';

class ConteudoRepository {
  final List<Conteudo> _itens = const [
    Conteudo(id: 1, titulo: 'Curso de programação', descricao: 'Aprenda programação de forma simples.', categoria: 'Estudos', detalhes: 'Aprenda lógica de programação, desenvolvimento de sites e criação de aplicativos.', tag: 'Aprenda algo novo', icone: Icons.laptop_mac_rounded, cor: Color(0xFFD6EBD2)),
    Conteudo(id: 2, titulo: 'Música da semana', descricao: 'Sugestões musicais para o seu dia.', categoria: 'Música', detalhes: 'Descubra novos estilos musicais e artistas para acompanhar seus momentos.', tag: 'Som do momento', icone: Icons.headphones_rounded, cor: Color(0xFFF8DDEB)),
    Conteudo(id: 3, titulo: 'Jogos em destaque', descricao: 'Jogos para todos os estilos.', categoria: 'Jogos', detalhes: 'Explore aventuras, desafios, quebra-cabeças e jogos de estratégia.', tag: 'Hora de jogar', icone: Icons.sports_esports_rounded, cor: Color(0xFFDCD9FA)),
    Conteudo(id: 4, titulo: 'Filmes para assistir', descricao: 'Histórias para sua próxima sessão.', categoria: 'Filmes', detalhes: 'Encontre sugestões de aventura, comédia, animação e ficção científica.', tag: 'Prepare a pipoca', icone: Icons.movie_rounded, cor: Color(0xFFFFE8C8)),
    Conteudo(id: 5, titulo: 'Novidades da tecnologia', descricao: 'Ideias e descobertas tecnológicas.', categoria: 'Tecnologia', detalhes: 'Conheça tendências, ferramentas digitais, programação e inteligência artificial.', tag: 'Fique por dentro', icone: Icons.memory_rounded, cor: Color(0xFFD4ECF7)),
    Conteudo(id: 6, titulo: 'Clube da leitura', descricao: 'Encontre livros e novas histórias.', categoria: 'Livros', detalhes: 'Descubra histórias de fantasia, mistério, aventura e outros gêneros.', tag: 'Uma página por vez', icone: Icons.auto_stories_rounded, cor: Color(0xFFF9E0D4)),
    Conteudo(id: 7, titulo: 'Dicas para estudar', descricao: 'Organize sua rotina de estudos.', categoria: 'Estudos', detalhes: 'Conheça técnicas de organização, planejamento e revisão.', tag: 'Dica útil', icone: Icons.edit_note_rounded, cor: Color(0xFFE1F0D8)),
    Conteudo(id: 8, titulo: 'Mundo dos games', descricao: 'Explore o universo gamer.', categoria: 'Jogos', detalhes: 'Descubra gêneros de jogos, curiosidades e experiências para jogar com amigos.', tag: 'Universo gamer', icone: Icons.gamepad_rounded, cor: Color(0xFFE7DDF8)),
    Conteudo(id: 9, titulo: 'Criatividade digital', descricao: 'Crie usando design e tecnologia.', categoria: 'Tecnologia', detalhes: 'Una criatividade e tecnologia em projetos de design, programação e criação digital.', tag: 'Solte a criatividade', icone: Icons.palette_rounded, cor: Color(0xFFF9DCE2)),
    Conteudo(id: 10, titulo: 'Curiosidades do espaço', descricao: 'Explore os mistérios do universo.', categoria: 'Estudos', detalhes: 'Conheça planetas, estrelas, galáxias e curiosidades sobre o universo.', tag: 'Além da Terra', icone: Icons.rocket_launch_rounded, cor: Color(0xFFDDE4FA)),
    Conteudo(id: 11, titulo: 'Fotografia criativa', descricao: 'Descubra novas formas de fotografar.', categoria: 'Tecnologia', detalhes: 'Explore composição, enquadramento e ideias para criar fotografias diferentes.', tag: 'Olhar criativo', icone: Icons.camera_alt_rounded, cor: Color(0xFFF7E5C9)),
    Conteudo(id: 12, titulo: 'Mundo da animação', descricao: 'Conheça histórias animadas.', categoria: 'Filmes', detalhes: 'Explore o universo das animações, seus estilos visuais e suas histórias.', tag: 'Imaginação sem limites', icone: Icons.animation_rounded, cor: Color(0xFFD8F0EA)),
  ];

  List<Conteudo> buscarTodos() => List.unmodifiable(_itens);
  List<String> buscarCategorias() => const ['Todos', 'Estudos', 'Música', 'Jogos', 'Filmes', 'Tecnologia', 'Livros'];
}
