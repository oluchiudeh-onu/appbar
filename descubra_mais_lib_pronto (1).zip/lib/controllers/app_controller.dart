import 'package:flutter/foundation.dart';
import '../models/conteudo.dart';
import '../repositories/conteudo_repository.dart';

class AppController extends ChangeNotifier {
  final ConteudoRepository repository = ConteudoRepository();
  int pagina = 0;
  String pesquisa = '';
  String categoriaSelecionada = 'Todos';
  final Set<int> _favoritos = {};

  List<Conteudo> get conteudos => repository.buscarTodos();
  List<String> get categorias => repository.buscarCategorias();
  int get quantidadeFavoritos => _favoritos.length;
  bool ehFavorito(int id) => _favoritos.contains(id);

  List<Conteudo> get filtrados => conteudos.where((item) {
    final catOk = categoriaSelecionada == 'Todos' || item.categoria == categoriaSelecionada;
    final termo = pesquisa.trim().toLowerCase();
    final buscaOk = termo.isEmpty || item.titulo.toLowerCase().contains(termo) ||
        item.descricao.toLowerCase().contains(termo) || item.categoria.toLowerCase().contains(termo);
    return catOk && buscaOk;
  }).toList();

  List<Conteudo> get favoritos => conteudos.where((item) => _favoritos.contains(item.id)).toList();

  void mudarPagina(int index) { pagina = index; notifyListeners(); }
  void pesquisar(String valor) { pesquisa = valor; notifyListeners(); }
  void selecionarCategoria(String valor) { categoriaSelecionada = valor; notifyListeners(); }
  void alternarFavorito(int id) {
    if (!_favoritos.add(id)) _favoritos.remove(id);
    notifyListeners();
  }
  void limparFiltros() {
    pesquisa = '';
    categoriaSelecionada = 'Todos';
    notifyListeners();
  }
}
