import 'package:flutter/material.dart';
import 'controllers/app_controller.dart';
import 'screens/home_page.dart';
import 'screens/explore_page.dart';
import 'screens/favorites_page.dart';
import 'screens/profile_page.dart';
import 'theme/app_theme.dart';
import 'widgets/app_navigation.dart';

void main() => runApp(const DescubraApp());

class DescubraApp extends StatefulWidget {
  const DescubraApp({super.key});

  @override
  State<DescubraApp> createState() => _DescubraAppState();
}

class _DescubraAppState extends State<DescubraApp> {
  late final AppController controller;

  @override
  void initState() {
    super.initState();
    controller = AppController();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Descubra+',
      theme: AppTheme.light,
      home: AnimatedBuilder(
        animation: controller,
        builder: (context, _) => Scaffold(
          body: SafeArea(
            child: IndexedStack(
              index: controller.pagina,
              children: [
                HomePage(controller: controller),
                ExplorePage(controller: controller),
                FavoritesPage(controller: controller),
                ProfilePage(controller: controller),
              ],
            ),
          ),
          bottomNavigationBar: AppNavigation(
            paginaAtual: controller.pagina,
            onSelecionar: controller.mudarPagina,
          ),
        ),
      ),
    );
  }
}
