import 'package:flutter/material.dart';
import '../controllers/app_controller.dart';
import '../theme/app_theme.dart';

class CategoryList extends StatelessWidget {
  final AppController controller;
  const CategoryList({super.key, required this.controller});

  static const Map<String, IconData> icones = {
    'Todos': Icons.apps_rounded, 'Estudos': Icons.school_rounded,
    'Música': Icons.music_note_rounded, 'Jogos': Icons.sports_esports_rounded,
    'Filmes': Icons.movie_rounded, 'Tecnologia': Icons.computer_rounded,
    'Livros': Icons.menu_book_rounded,
  };

  @override
  Widget build(BuildContext context) => SizedBox(
    height: 116,
    child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      scrollDirection: Axis.horizontal,
      itemCount: controller.categorias.length,
      separatorBuilder: (_, __) => const SizedBox(width: 12),
      itemBuilder: (context, index) {
        final categoria = controller.categorias[index];
        final ativa = controller.categoriaSelecionada == categoria;
        return GestureDetector(
          onTap: () {
            controller.selecionarCategoria(categoria);
            controller.mudarPagina(1);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            width: 104,
            decoration: BoxDecoration(
              color: ativa ? const Color(0xFFC5E4BE) : AppTheme.verdeClaro,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: ativa ? AppTheme.verde : Colors.transparent),
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icones[categoria] ?? Icons.category_rounded, size: 31, color: AppTheme.verde),
              const SizedBox(height: 9),
              Text(categoria, style: const TextStyle(fontWeight: FontWeight.w600, color: AppTheme.texto)),
            ]),
          ),
        );
      },
    ),
  );
}
