import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class AppNavigation extends StatelessWidget {
  final int paginaAtual;
  final ValueChanged<int> onSelecionar;
  const AppNavigation({super.key, required this.paginaAtual, required this.onSelecionar});

  @override
  Widget build(BuildContext context) => NavigationBar(
    selectedIndex: paginaAtual,
    backgroundColor: AppTheme.fundo,
    indicatorColor: AppTheme.verdeClaro,
    height: 76,
    onDestinationSelected: onSelecionar,
    destinations: const [
      NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded, color: AppTheme.verde), label: 'Início'),
      NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore_rounded, color: AppTheme.verde), label: 'Explorar'),
      NavigationDestination(icon: Icon(Icons.favorite_border_rounded), selectedIcon: Icon(Icons.favorite_rounded, color: AppTheme.verde), label: 'Favoritos'),
      NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded, color: AppTheme.verde), label: 'Perfil'),
    ],
  );
}
