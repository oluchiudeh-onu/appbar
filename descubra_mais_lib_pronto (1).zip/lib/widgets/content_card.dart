import 'package:flutter/material.dart';
import '../controllers/app_controller.dart';
import '../models/conteudo.dart';
import '../screens/details_page.dart';
import '../theme/app_theme.dart';

class ContentCard extends StatelessWidget {
  final Conteudo conteudo;
  final AppController controller;
  final bool compacto;
  const ContentCard({super.key, required this.conteudo, required this.controller, this.compacto = false});

  @override
  Widget build(BuildContext context) {
    final favorito = controller.ehFavorito(conteudo.id);
    return Card(
      color: compacto ? Colors.white : AppTheme.lilas,
      elevation: 1,
      margin: const EdgeInsets.only(bottom: 13),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute(
          builder: (_) => DetailsPage(conteudo: conteudo, controller: controller),
        )),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(
              width: compacto ? 62 : 72, height: compacto ? 62 : 72,
              decoration: BoxDecoration(color: conteudo.cor, borderRadius: BorderRadius.circular(17)),
              child: Icon(conteudo.icone, color: AppTheme.verde, size: 32),
            ),
            const SizedBox(width: 13),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(conteudo.titulo, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppTheme.texto)),
              const SizedBox(height: 5),
              Text(conteudo.descricao, maxLines: 2, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppTheme.cinza, height: 1.35)),
            ])),
            IconButton(
              tooltip: favorito ? 'Remover favorito' : 'Adicionar favorito',
              onPressed: () => controller.alternarFavorito(conteudo.id),
              icon: Icon(favorito ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                color: favorito ? Colors.pink : AppTheme.cinza),
            ),
          ]),
        ),
      ),
    );
  }
}
