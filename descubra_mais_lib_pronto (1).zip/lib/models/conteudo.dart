import 'package:flutter/material.dart';

class Conteudo {
  final int id;
  final String titulo, descricao, categoria, detalhes, tag;
  final IconData icone;
  final Color cor;

  const Conteudo({
    required this.id,
    required this.titulo,
    required this.descricao,
    required this.categoria,
    required this.detalhes,
    required this.tag,
    required this.icone,
    required this.cor,
  });
}
