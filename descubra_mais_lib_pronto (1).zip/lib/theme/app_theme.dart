import 'package:flutter/material.dart';

class AppTheme {
  static const verde = Color(0xFF438F50);
  static const verdeClaro = Color(0xFFD9EED5);
  static const fundo = Color(0xFFFCF9FF);
  static const lilas = Color(0xFFF1EAF8);
  static const texto = Color(0xFF292630);
  static const cinza = Color(0xFF85818D);

  static ThemeData get light => ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: fundo,
    colorScheme: ColorScheme.fromSeed(seedColor: verde, surface: fundo),
    appBarTheme: const AppBarTheme(backgroundColor: fundo, foregroundColor: texto, elevation: 0),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 17),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFE5DDEB))),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFE5DDEB))),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: verde, width: 1.5)),
    ),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
      backgroundColor: verde, foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    )),
  );
}
