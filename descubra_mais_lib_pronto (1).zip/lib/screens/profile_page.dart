import 'package:flutter/material.dart';
import '../controllers/app_controller.dart';
import '../theme/app_theme.dart';

class ProfilePage extends StatelessWidget {
  final AppController controller;
  const ProfilePage({super.key, required this.controller});

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.only(bottom: 28), children: [
    const Padding(padding: EdgeInsets.fromLTRB(24, 24, 24, 24),
      child: Text('Meu perfil', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: AppTheme.texto))),
    Center(child: Container(width: 108, height: 108,
      decoration: BoxDecoration(color: AppTheme.verdeClaro, borderRadius: BorderRadius.circular(35)),
      child: const Icon(Icons.person_rounded, size: 64, color: AppTheme.verde))),
    const SizedBox(height: 16),
    const Center(child: Text('Olá, descobridor(a)!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppTheme.texto))),
    const SizedBox(height: 6),
    const Center(child: Text('Explore. Aprenda. Divirta-se.', style: TextStyle(color: AppTheme.cinza))),
    Padding(padding: const EdgeInsets.all(24), child: Row(children: [
      _estatistica(Icons.favorite_rounded, '${controller.quantidadeFavoritos}', 'Favoritos'),
      const SizedBox(width: 10),
      _estatistica(Icons.category_rounded, '${controller.categorias.length - 1}', 'Categorias'),
      const SizedBox(width: 10),
      _estatistica(Icons.explore_rounded, '${controller.conteudos.length}', 'Conteúdos'),
    ])),
    const Padding(padding: EdgeInsets.symmetric(horizontal: 24),
      child: Text('Preferências', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: AppTheme.texto))),
    const SizedBox(height: 10),
    _opcao(Icons.favorite_outline_rounded, 'Meus favoritos', 'Veja o que você salvou', () => controller.mudarPagina(2)),
    _opcao(Icons.explore_outlined, 'Descobrir conteúdos', 'Encontre novas ideias', () { controller.limparFiltros(); controller.mudarPagina(1); }),
    _opcao(Icons.category_outlined, 'Todas as categorias', 'Explore os diferentes temas', () { controller.limparFiltros(); controller.mudarPagina(1); }),
    _opcao(Icons.info_outline_rounded, 'Sobre o Descubra+', 'Conheça o aplicativo', () {
      showAboutDialog(context: context, applicationName: 'Descubra+', applicationVersion: '1.0.0',
        children: const [Text('Um espaço para descobrir conteúdos de estudos, música, jogos, filmes, livros e tecnologia.')]);
    }),
  ]);

  Widget _estatistica(IconData icon, String numero, String legenda) => Expanded(child: Container(
    padding: const EdgeInsets.symmetric(vertical: 17, horizontal: 3),
    decoration: BoxDecoration(color: AppTheme.lilas, borderRadius: BorderRadius.circular(19)),
    child: Column(children: [
      Icon(icon, color: AppTheme.verde, size: 25), const SizedBox(height: 7),
      Text(numero, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: AppTheme.texto)),
      const SizedBox(height: 3), Text(legenda, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: AppTheme.cinza)),
    ]),
  ));

  Widget _opcao(IconData icon, String titulo, String descricao, VoidCallback acao) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 3),
    leading: Container(width: 46, height: 46,
      decoration: BoxDecoration(color: AppTheme.verdeClaro, borderRadius: BorderRadius.circular(14)),
      child: Icon(icon, color: AppTheme.verde)),
    title: Text(titulo, style: const TextStyle(fontWeight: FontWeight.w600, color: AppTheme.texto)),
    subtitle: Text(descricao, style: const TextStyle(color: AppTheme.cinza)),
    trailing: const Icon(Icons.chevron_right_rounded, color: AppTheme.cinza),
    onTap: acao,
  );
}
