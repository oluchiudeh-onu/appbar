import 'package:flutter/material.dart';
import '../controllers/app_controller.dart';
import '../models/conteudo.dart';
import '../theme/app_theme.dart';

class DetailsPage extends StatelessWidget {
  final Conteudo conteudo;
  final AppController controller;
  const DetailsPage({super.key, required this.conteudo, required this.controller});

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (context, _) {
      final favorito = controller.ehFavorito(conteudo.id);
      return Scaffold(
        appBar: AppBar(title: const Text('Detalhes'), actions: [
          IconButton(onPressed: () => controller.alternarFavorito(conteudo.id),
            icon: Icon(favorito ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              color: favorito ? Colors.pink : AppTheme.verde)),
        ]),
        body: ListView(padding: const EdgeInsets.fromLTRB(24, 12, 24, 30), children: [
          Container(height: 220, decoration: BoxDecoration(color: conteudo.cor, borderRadius: BorderRadius.circular(28)),
            child: Icon(conteudo.icone, size: 100, color: AppTheme.verde)),
          const SizedBox(height: 24),
          Align(alignment: Alignment.centerLeft, child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(color: AppTheme.verdeClaro, borderRadius: BorderRadius.circular(30)),
            child: Text(conteudo.categoria, style: const TextStyle(color: AppTheme.verde, fontWeight: FontWeight.w600)))),
          const SizedBox(height: 18),
          Text(conteudo.titulo, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: AppTheme.texto)),
          const SizedBox(height: 10),
          Text(conteudo.tag, style: const TextStyle(fontSize: 16, color: AppTheme.verde, fontWeight: FontWeight.w600)),
          const SizedBox(height: 18),
          Text(conteudo.detalhes, style: const TextStyle(fontSize: 16, height: 1.7, color: AppTheme.cinza)),
          const SizedBox(height: 28),
          SizedBox(height: 52, child: FilledButton.icon(
            onPressed: () => controller.alternarFavorito(conteudo.id),
            icon: Icon(favorito ? Icons.favorite_rounded : Icons.favorite_border_rounded),
            label: Text(favorito ? 'Remover dos favoritos' : 'Salvar nos favoritos'))),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: () => Navigator.pop(context),
            style: OutlinedButton.styleFrom(foregroundColor: AppTheme.verde, minimumSize: const Size.fromHeight(50),
              side: const BorderSide(color: AppTheme.verde), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
            child: const Text('Voltar para explorar')),
        ]),
      );
    },
  );
}
