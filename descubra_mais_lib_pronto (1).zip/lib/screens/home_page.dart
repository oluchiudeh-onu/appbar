import 'package:flutter/material.dart';
import '../controllers/app_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/category_list.dart';
import '../widgets/content_card.dart';

class HomePage extends StatelessWidget {
  final AppController controller;
  const HomePage({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final destaques = controller.filtrados.take(3).toList();
    return ListView(padding: const EdgeInsets.only(bottom: 24), children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 18),
        child: Row(children: [
          const Icon(Icons.auto_awesome_rounded, color: AppTheme.verde, size: 38),
          const SizedBox(width: 11),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Descubra+', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppTheme.texto)),
            Text('Um mundo de possibilidades', style: TextStyle(color: AppTheme.cinza)),
          ])),
          IconButton(onPressed: () => controller.mudarPagina(2), icon: const Icon(Icons.favorite_border_rounded, color: AppTheme.verde)),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFDDF0D8), Color(0xFFF0E5FA)]),
            borderRadius: BorderRadius.circular(26),
          ),
          child: const Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Olá! 👋', style: TextStyle(fontSize: 29, fontWeight: FontWeight.bold, color: AppTheme.texto)),
              SizedBox(height: 8),
              Text('O que você deseja descobrir hoje?', style: TextStyle(color: AppTheme.cinza, height: 1.4)),
            ])),
            Icon(Icons.auto_awesome_rounded, size: 56, color: AppTheme.verde),
          ]),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
        child: TextField(
          onChanged: controller.pesquisar,
          decoration: InputDecoration(
            hintText: 'Pesquisar conteúdos...',
            prefixIcon: const Icon(Icons.search_rounded, color: AppTheme.verde),
            suffixIcon: controller.pesquisa.isNotEmpty
                ? IconButton(onPressed: controller.limparFiltros, icon: const Icon(Icons.close_rounded))
                : null,
          ),
        ),
      ),
      const Padding(
        padding: EdgeInsets.fromLTRB(24, 27, 24, 15),
        child: Text('Categorias', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppTheme.texto)),
      ),
      CategoryList(controller: controller),
      Padding(
        padding: const EdgeInsets.fromLTRB(24, 26, 24, 14),
        child: Row(children: [
          const Expanded(child: Text('Feito para você ✨', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: AppTheme.texto))),
          TextButton(onPressed: () { controller.limparFiltros(); controller.mudarPagina(1); }, child: const Text('Ver todos')),
        ]),
      ),
      if (destaques.isEmpty)
        const Padding(padding: EdgeInsets.all(24), child: Text('Nenhum conteúdo encontrado.'))
      else
        ...destaques.map((item) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: ContentCard(conteudo: item, controller: controller),
        )),
      Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 0),
        child: Container(
          padding: const EdgeInsets.all(19),
          decoration: BoxDecoration(color: const Color(0xFFE9E2F7), borderRadius: BorderRadius.circular(22)),
          child: const Row(children: [
            Icon(Icons.lightbulb_outline_rounded, size: 34, color: Color(0xFF8268B2)),
            SizedBox(width: 13),
            Expanded(child: Text('Sua próxima descoberta está a um toque de distância!', style: TextStyle(fontWeight: FontWeight.w600, color: AppTheme.texto))),
          ]),
        ),
      ),
    ]);
  }
}
