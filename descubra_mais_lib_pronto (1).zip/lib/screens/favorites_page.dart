import 'package:flutter/material.dart';
import '../controllers/app_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/content_card.dart';

class FavoritesPage extends StatelessWidget {
  final AppController controller;
  const FavoritesPage({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final itens = controller.favoritos;
    return Column(children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(24, 24, 24, 20),
        child: Align(alignment: Alignment.centerLeft, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Favoritos', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: AppTheme.texto)),
          SizedBox(height: 4),
          Text('Seus conteúdos salvos', style: TextStyle(color: AppTheme.cinza)),
        ])),
      ),
      Expanded(child: itens.isEmpty
        ? Center(child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(padding: const EdgeInsets.all(25), decoration: const BoxDecoration(color: Color(0xFFF8DDEB), shape: BoxShape.circle),
                child: const Icon(Icons.favorite_border_rounded, color: Colors.pink, size: 52)),
              const SizedBox(height: 22),
              const Text('Ainda não há favoritos', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: AppTheme.texto)),
              const SizedBox(height: 10),
              const Text('Toque no coração dos conteúdos para guardá-los aqui.',
                textAlign: TextAlign.center, style: TextStyle(color: AppTheme.cinza, height: 1.5)),
              const SizedBox(height: 20),
              FilledButton(onPressed: () => controller.mudarPagina(1), child: const Text('Explorar conteúdos')),
            ]),
          ))
        : ListView(padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
            children: itens.map((item) => ContentCard(conteudo: item, controller: controller)).toList())),
    ]);
  }
}
