import 'package:flutter/material.dart';
import '../controllers/app_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/content_card.dart';

class ExplorePage extends StatelessWidget {
  final AppController controller;
  const ExplorePage({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final itens = controller.filtrados;
    return Column(children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(24, 24, 24, 18),
        child: Align(alignment: Alignment.centerLeft, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Explorar', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: AppTheme.texto)),
          SizedBox(height: 4),
          Text('Encontre algo interessante', style: TextStyle(color: AppTheme.cinza)),
        ])),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: TextField(
          onChanged: controller.pesquisar,
          decoration: InputDecoration(
            hintText: 'Pesquisar conteúdos...',
            prefixIcon: const Icon(Icons.search_rounded, color: AppTheme.verde),
            suffixIcon: controller.pesquisa.isNotEmpty
                ? IconButton(onPressed: controller.limparFiltros, icon: const Icon(Icons.close_rounded))
                : null,
          ),
        ),
      ),
      const SizedBox(height: 14),
      SizedBox(height: 44, child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        children: controller.categorias.map((categoria) {
          final ativo = controller.categoriaSelecionada == categoria;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ChoiceChip(
              label: Text(categoria), selected: ativo,
              onSelected: (_) => controller.selecionarCategoria(categoria),
              selectedColor: AppTheme.verdeClaro, backgroundColor: Colors.white,
              side: BorderSide(color: ativo ? AppTheme.verde : const Color(0xFFE5DDEB)),
            ),
          );
        }).toList(),
      )),
      const SizedBox(height: 10),
      Expanded(child: itens.isEmpty
        ? const Center(child: Text('Nenhum resultado encontrado.', style: TextStyle(color: AppTheme.cinza)))
        : ListView.builder(
            padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
            itemCount: itens.length,
            itemBuilder: (context, index) => ContentCard(conteudo: itens[index], controller: controller, compacto: true),
          )),
    ]);
  }
}
